function _instantUpdateSettings() {
return {
	"baseLineGUID": "8ffd402805fd4e95bb7cda0aea5b6a9b",
	"baseURL": "http://phonegapinstantupdate.s3.amazonaws.com/",
	"displayMessageAfterUpdate": true,
	"message": "Version {version}",
	"systemMessages": "Verbose"
};
}